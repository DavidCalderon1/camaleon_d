<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $cuentaGrupo->nombre !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $cuentaGrupo->descripcion !!}</p>
</div>

<!-- Ajuste Field -->
<div class="form-group">
    {!! Form::label('ajuste', 'Ajuste:') !!}
    <p>{!! $cuentaGrupo->ajuste !!}</p>
</div>

<!-- Cntg Cntcid Field -->
<div class="form-group">
    {!! Form::label('cntg_cntcid', 'Cntg Cntcid:') !!}
    <p>{!! $cuentaGrupo->cntg_cntcid !!}</p>
</div>

<!-- Cntg Id Field -->
<div class="form-group">
    {!! Form::label('cntg_id', 'Cntg Id:') !!}
    <p>{!! $cuentaGrupo->cntg_id !!}</p>
</div>

