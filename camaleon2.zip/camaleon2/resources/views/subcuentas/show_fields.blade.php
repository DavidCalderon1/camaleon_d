<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $subcuenta->nombre !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $subcuenta->descripcion !!}</p>
</div>

<!-- Ajuste Field -->
<div class="form-group">
    {!! Form::label('ajuste', 'Ajuste:') !!}
    <p>{!! $subcuenta->ajuste !!}</p>
</div>

<!-- Scnt Nativa Field -->
<div class="form-group">
    {!! Form::label('scnt_nativa', 'Scnt Nativa:') !!}
    <p>{!! $subcuenta->scnt_nativa !!}</p>
</div>

<!-- Scnt Cntid Field -->
<div class="form-group">
    {!! Form::label('scnt_cntid', 'Scnt Cntid:') !!}
    <p>{!! $subcuenta->scnt_cntid !!}</p>
</div>

<!-- Scnt Id Field -->
<div class="form-group">
    {!! Form::label('scnt_id', 'Scnt Id:') !!}
    <p>{!! $subcuenta->scnt_id !!}</p>
</div>

