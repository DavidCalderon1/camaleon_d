<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $cuentaClase->nombre !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $cuentaClase->descripcion !!}</p>
</div>

<!-- Ajuste Field -->
<div class="form-group">
    {!! Form::label('ajuste', 'Ajuste:') !!}
    <p>{!! $cuentaClase->ajuste !!}</p>
</div>

<!-- Cntc Naturaleza Field -->
<div class="form-group">
    {!! Form::label('cntc_naturaleza', 'Cntc Naturaleza:') !!}
    <p>{!! $cuentaClase->cntc_naturaleza !!}</p>
</div>

<!-- Cntc Id Field -->
<div class="form-group">
    {!! Form::label('cntc_id', 'Cntc Id:') !!}
    <p>{!! $cuentaClase->cntc_id !!}</p>
</div>

