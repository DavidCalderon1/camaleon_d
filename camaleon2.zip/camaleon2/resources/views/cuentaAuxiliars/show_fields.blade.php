<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $cuentaAuxiliar->nombre !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $cuentaAuxiliar->descripcion !!}</p>
</div>

<!-- Ajuste Field -->
<div class="form-group">
    {!! Form::label('ajuste', 'Ajuste:') !!}
    <p>{!! $cuentaAuxiliar->ajuste !!}</p>
</div>

<!-- Reqta Field -->
<div class="form-group">
    {!! Form::label('reqta', 'Reqta:') !!}
    <p>{!! $cuentaAuxiliar->reqta !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $cuentaAuxiliar->estado !!}</p>
</div>

<!-- Cntaux Scntid Field -->
<div class="form-group">
    {!! Form::label('cntaux_scntid', 'Cntaux Scntid:') !!}
    <p>{!! $cuentaAuxiliar->cntaux_scntid !!}</p>
</div>

<!-- Cntaux Id Field -->
<div class="form-group">
    {!! Form::label('cntaux_id', 'Cntaux Id:') !!}
    <p>{!! $cuentaAuxiliar->cntaux_id !!}</p>
</div>

